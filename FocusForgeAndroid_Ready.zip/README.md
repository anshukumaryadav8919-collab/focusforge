# FocusForge — Android MVP

An original focus timer and habit-tracking app inspired by common digital-wellbeing tools.

## Included
- 15/25/45/60-minute focus sessions
- Local session count and daily streak
- Select installed apps to block during an active focus session
- Accessibility-service-based app blocking (user must enable it manually)
- Local-only preferences; no account or server required

## Requirements
- Android Studio (current stable)
- Android SDK 35 installed
- Internet connection for the first Gradle dependency sync
- Android 8.0 (API 26) or newer for the app

## Open and run
1. Download and unzip this project.
2. Open Android Studio.
3. Choose **Open**, then select the `FocusForgeAndroid` folder.
4. Wait for Gradle sync to finish. If prompted, install Android SDK Platform 35.
5. Connect an Android phone with USB debugging enabled, or create an emulator.
6. Press **Run** (green triangle).

## Enable app blocking
1. Open FocusForge.
2. Choose **Choose apps to block** and select apps.
3. Open **Accessibility settings** from the Focus screen.
4. Find FocusForge under downloaded/installed services and enable it.
5. Start a focus session and test with one non-essential app first.

Android's accessibility setting is powerful. This service only watches window-change events and sends you to the Home screen if a selected app opens during an active session. It does not read screen text or collect data.

## Important MVP limitations
- App blocking is best-effort; Android manufacturers can restrict background/service behavior.
- Screen-time analytics for all apps are not included yet. Android requires a separate Usage Access permission and careful handling of usage data.
- The streak is based on completed focus sessions per calendar day. This starter uses simple local preferences and is intended for learning/testing, not as a production-hardened app.
- The project requests broad package visibility so the app can show launchable apps for selection. Review Google Play's package-visibility and accessibility policies before publishing.
- The timer UI is active while the app is open. If you want reliable notifications, a persistent timer notification, pause/resume, and reboot recovery, add a foreground service in the next iteration.

## Suggested next steps
1. Add a persistent foreground service and completion notification.
2. Add Android Usage Access for actual daily screen-time totals.
3. Add onboarding, a privacy page, and stronger persistence.
4. Test on multiple Android versions and devices.

## Easiest way to get the APK (no Android Studio needed)
1. Create a free GitHub account and a new repository (works from a phone browser too).
2. Upload everything from this folder (including the hidden `.github` folder) to the repo's `main` branch.
3. Open the **Actions** tab — the "Build APK" workflow runs automatically (about 5 minutes).
4. When it finishes, open the repo's **Releases** page and tap **FocusForge.apk** on your phone to download it.
5. Open the file and allow "Install unknown apps" for your browser when Android asks.
6. Enable accessibility blocking inside the app (see below). On Android 13+ you may first need
   App info → ⋮ → "Allow restricted settings" before the accessibility toggle becomes available.
