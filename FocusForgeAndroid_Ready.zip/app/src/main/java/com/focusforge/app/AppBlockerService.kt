package com.focusforge.app

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.view.accessibility.AccessibilityEvent

class AppBlockerService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val prefs = getSharedPreferences("focusforge_prefs", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("focus_active", false)) return
        // Stop blocking once the session time is up, even if the app UI was closed.
        if (System.currentTimeMillis() >= prefs.getLong("focus_end", 0L)) return
        val packageName = event.packageName?.toString() ?: return
        if (packageName == this.packageName) return
        val blocked = prefs.getStringSet("blocked_packages", emptySet()) ?: emptySet()
        if (blocked.contains(packageName)) {
            performGlobalAction(GLOBAL_ACTION_HOME)
        }
    }

    override fun onInterrupt() = Unit
}
