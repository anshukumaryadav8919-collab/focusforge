package com.focusforge.app

import android.accessibilityservice.AccessibilityServiceInfo
import android.app.Activity
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

private const val PREFS = "focusforge_prefs"
private const val KEY_END = "focus_end"
private const val KEY_ACTIVE = "focus_active"
private const val KEY_BLOCKED = "blocked_packages"
private const val KEY_SESSIONS = "sessions"
private const val KEY_LAST_DAY = "last_completed_day"
private const val KEY_STREAK = "streak"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FocusForgeScreen() }
    }
}

data class AppChoice(val label: String, val packageName: String)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FocusForgeScreen() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE) }
    var refresh by remember { mutableIntStateOf(0) }
    var duration by remember { mutableIntStateOf(25) }
    var remaining by remember { mutableLongStateOf(0L) }
    var active by remember { mutableStateOf(prefs.getBoolean(KEY_ACTIVE, false)) }
    var selectedTab by remember { mutableIntStateOf(0) }
    var showApps by remember { mutableStateOf(false) }

    val apps = remember {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .mapNotNull {
                val pkg = it.activityInfo?.packageName ?: return@mapNotNull null
                if (pkg == context.packageName) null
                else AppChoice(it.loadLabel(pm).toString(), pkg)
            }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase(Locale.getDefault()) }
    }
    var blocked by remember {
        mutableStateOf(prefs.getStringSet(KEY_BLOCKED, emptySet())?.toSet() ?: emptySet())
    }

    LaunchedEffect(active, refresh) {
        while (active) {
            val end = prefs.getLong(KEY_END, 0L)
            val left = max(0L, (end - System.currentTimeMillis()) / 1000L)
            remaining = left
            if (left <= 0L) {
                prefs.edit().putBoolean(KEY_ACTIVE, false).apply()
                active = false
                completeSession(prefs)
                refresh++
                break
            }
            delay(500)
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = androidx.compose.ui.graphics.Color(0xFF8BE9A8),
        background = androidx.compose.ui.graphics.Color(0xFF101511),
        surface = androidx.compose.ui.graphics.Color(0xFF1A211C)
    )) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("FocusForge", fontWeight = FontWeight.Bold) },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.background
                    )
                )
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { padding ->
            if (showApps) {
                Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
                    Text("Choose apps to block", style = MaterialTheme.typography.headlineSmall)
                    Text("Selected apps return to the home screen while a focus session is running.")
                    Spacer(Modifier.height(12.dp))
                    LazyColumn(Modifier.weight(1f)) {
                        items(apps, key = { it.packageName }) { app ->
                            Row(
                                Modifier.fillMaxWidth().padding(vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(app.label)
                                    Text(app.packageName, style = MaterialTheme.typography.labelSmall)
                                }
                                Checkbox(
                                    checked = blocked.contains(app.packageName),
                                    onCheckedChange = { checked ->
                                        blocked = if (checked) blocked + app.packageName else blocked - app.packageName
                                        prefs.edit().putStringSet(KEY_BLOCKED, blocked).apply()
                                    }
                                )
                            }
                            HorizontalDivider()
                        }
                    }
                    Button(onClick = { showApps = false }, modifier = Modifier.fillMaxWidth()) {
                        Text("Done")
                    }
                }
            } else {
                Column(
                    Modifier.fillMaxSize().padding(padding).padding(horizontal = 20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    TabRow(selectedTabIndex = selectedTab) {
                        Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Focus") })
                        Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("Progress") })
                        Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("Settings") })
                    }
                    Spacer(Modifier.height(24.dp))
                    when (selectedTab) {
                        0 -> {
                            Text(if (active) "Stay with your goal" else "Make time count",
                                style = MaterialTheme.typography.headlineSmall)
                            Spacer(Modifier.height(20.dp))
                            Text(
                                formatTime(if (active) remaining else duration * 60L),
                                style = MaterialTheme.typography.displayLarge,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(Modifier.height(16.dp))
                            if (!active) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf(15, 25, 45, 60).forEach { minutes ->
                                        FilterChip(
                                            selected = duration == minutes,
                                            onClick = { duration = minutes },
                                            label = { Text("${minutes}m") }
                                        )
                                    }
                                }
                                Spacer(Modifier.height(18.dp))
                                Button(
                                    onClick = {
                                        val end = System.currentTimeMillis() + duration * 60_000L
                                        prefs.edit().putLong(KEY_END, end).putBoolean(KEY_ACTIVE, true).apply()
                                        active = true
                                        remaining = duration * 60L
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) { Text("Start focus session") }
                            } else {
                                Text("Selected apps: ${blocked.size}")
                                Spacer(Modifier.height(12.dp))
                                Button(
                                    onClick = {
                                        prefs.edit().putBoolean(KEY_ACTIVE, false).putLong(KEY_END, 0L).apply()
                                        active = false
                                        refresh++
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                                ) { Text("End session") }
                            }
                            Spacer(Modifier.height(16.dp))
                            OutlinedButton(onClick = { showApps = true }, modifier = Modifier.fillMaxWidth()) {
                                Text("Choose apps to block")
                            }
                            if (!isAccessibilityEnabled(context)) {
                                Spacer(Modifier.height(8.dp))
                                Text("To enable app blocking, open Settings and turn on FocusForge under Accessibility.")
                                OutlinedButton(
                                    onClick = { context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
                                    modifier = Modifier.fillMaxWidth()
                                ) { Text("Open Accessibility settings") }
                            } else {
                                Text("App blocking service is enabled.")
                            }
                        }
                        1 -> {
                            val sessions = prefs.getInt(KEY_SESSIONS, 0)
                            val streak = prefs.getInt(KEY_STREAK, 0)
                            Text("Your progress", style = MaterialTheme.typography.headlineSmall)
                            Spacer(Modifier.height(18.dp))
                            StatCard("Completed focus sessions", sessions.toString())
                            StatCard("Current daily streak", "$streak day(s)")
                            StatCard("Apps selected for blocking", blocked.size.toString())
                            Text("A session counts when the timer reaches zero. Ending early does not count.",
                                style = MaterialTheme.typography.bodySmall)
                        }
                        else -> {
                            Text("Settings", style = MaterialTheme.typography.headlineSmall)
                            Spacer(Modifier.height(12.dp))
                            Text("FocusForge stores basic progress on this device.")
                            Text("App blocking uses Android Accessibility. Enable it only if you understand and agree to the behavior.")
                            Spacer(Modifier.height(12.dp))
                            OutlinedButton(
                                onClick = { context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("Accessibility settings") }
                            OutlinedButton(
                                onClick = {
                                    prefs.edit().clear().apply()
                                    blocked = emptySet()
                                    active = false
                                    refresh++
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("Reset all progress") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatCard(label: String, value: String) {
    Card(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(label, Modifier.weight(1f))
            Text(value, fontWeight = FontWeight.Bold)
        }
    }
}

private fun formatTime(seconds: Long): String {
    val safe = max(0L, seconds)
    return "%02d:%02d".format(safe / 60, safe % 60)
}

private fun completeSession(prefs: android.content.SharedPreferences) {
    val sessions = prefs.getInt(KEY_SESSIONS, 0) + 1
    val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    val lastDay = prefs.getString(KEY_LAST_DAY, "") ?: ""
    val yesterday = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(System.currentTimeMillis() - 86_400_000L))
    val streak = when (lastDay) {
        today -> prefs.getInt(KEY_STREAK, 1)
        yesterday -> prefs.getInt(KEY_STREAK, 0) + 1
        else -> 1
    }
    prefs.edit()
        .putInt(KEY_SESSIONS, sessions)
        .putString(KEY_LAST_DAY, today)
        .putInt(KEY_STREAK, streak)
        .apply()
}

private fun isAccessibilityEnabled(context: Context): Boolean {
    val manager = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
    return manager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
        .any { it.resolveInfo.serviceInfo.packageName == context.packageName }
}
